import { useState, useEffect, useCallback, useMemo, useRef } from "react";

const SAMPLE_DATA = {
  metadata: {
    event: "Baseball D1",
    year: 2025,
    scraped_at: "2025-09-15T14:30:00",
    source: "https://www.baseballsoftball.be",
  },
  batting: [
    { Player: "L. Hendricks", Team: "MER", G: "28", AB: "98", R: "22", H: "38", "2B": "9", "3B": "2", HR: "5", RBI: "28", BB: "15", SO: "12", SB: "8", AVG: ".388", OBP: ".460", SLG: ".643", OPS: "1.103" },
    { Player: "T. Vanden Berg", Team: "HOB", G: "26", AB: "92", R: "18", H: "33", "2B": "7", "3B": "1", HR: "4", RBI: "22", BB: "12", SO: "15", SB: "5", AVG: ".359", OBP: ".433", SLG: ".565", OPS: ".998" },
    { Player: "M. De Smet", Team: "BRU", G: "27", AB: "95", R: "20", H: "33", "2B": "8", "3B": "0", HR: "6", RBI: "25", BB: "14", SO: "18", SB: "3", AVG: ".347", OBP: ".422", SLG: ".579", OPS: "1.001" },
    { Player: "J. Peeters", Team: "BOR", G: "25", AB: "88", R: "16", H: "30", "2B": "5", "3B": "1", HR: "3", RBI: "19", BB: "10", SO: "14", SB: "12", AVG: ".341", OBP: ".408", SLG: ".500", OPS: ".908" },
    { Player: "K. Janssen", Team: "DEU", G: "28", AB: "102", R: "19", H: "34", "2B": "6", "3B": "2", HR: "2", RBI: "17", BB: "8", SO: "20", SB: "6", AVG: ".333", OBP: ".382", SLG: ".461", OPS: ".843" },
    { Player: "R. Claes", Team: "MSG", G: "24", AB: "80", R: "14", H: "26", "2B": "4", "3B": "1", HR: "3", RBI: "15", BB: "11", SO: "16", SB: "2", AVG: ".325", OBP: ".407", SLG: ".500", OPS: ".907" },
    { Player: "S. Wouters", Team: "NAM", G: "26", AB: "90", R: "15", H: "29", "2B": "7", "3B": "0", HR: "2", RBI: "14", BB: "9", SO: "22", SB: "4", AVG: ".322", OBP: ".384", SLG: ".456", OPS: ".840" },
    { Player: "A. Lambert", Team: "BRA", G: "27", AB: "94", R: "17", H: "30", "2B": "5", "3B": "1", HR: "4", RBI: "21", BB: "13", SO: "19", SB: "1", AVG: ".319", OBP: ".397", SLG: ".500", OPS: ".897" },
    { Player: "N. Dubois", Team: "MER", G: "28", AB: "100", R: "21", H: "31", "2B": "8", "3B": "1", HR: "3", RBI: "18", BB: "16", SO: "11", SB: "7", AVG: ".310", OBP: ".405", SLG: ".470", OPS: ".875" },
    { Player: "B. Van Damme", Team: "HOB", G: "25", AB: "86", R: "13", H: "26", "2B": "3", "3B": "0", HR: "2", RBI: "12", BB: "7", SO: "25", SB: "9", AVG: ".302", OBP: ".355", SLG: ".407", OPS: ".762" },
    { Player: "C. Martens", Team: "BRU", G: "24", AB: "78", R: "11", H: "23", "2B": "4", "3B": "1", HR: "1", RBI: "10", BB: "6", SO: "17", SB: "3", AVG: ".295", OBP: ".345", SLG: ".397", OPS: ".742" },
    { Player: "D. Hermans", Team: "DEU", G: "26", AB: "91", R: "12", H: "26", "2B": "5", "3B": "0", HR: "1", RBI: "11", BB: "8", SO: "21", SB: "5", AVG: ".286", OBP: ".343", SLG: ".363", OPS: ".706" },
  ],
  pitching: [
    { Player: "V. Moens", Team: "MER", W: "8", L: "2", ERA: "1.85", G: "14", GS: "12", IP: "82.1", H: "58", R: "20", ER: "17", BB: "22", SO: "95", WHIP: "0.97", "K/9": "10.38" },
    { Player: "P. Raes", Team: "HOB", W: "7", L: "3", ERA: "2.12", G: "13", GS: "11", IP: "76.1", H: "55", R: "22", ER: "18", BB: "18", SO: "82", WHIP: "0.96", "K/9": "9.67" },
    { Player: "F. Willems", Team: "BOR", W: "6", L: "3", ERA: "2.45", G: "15", GS: "10", IP: "69.2", H: "52", R: "21", ER: "19", BB: "24", SO: "71", WHIP: "1.09", "K/9": "9.17" },
    { Player: "G. Leclercq", Team: "BRU", W: "5", L: "4", ERA: "2.78", G: "12", GS: "12", IP: "71.0", H: "60", R: "25", ER: "22", BB: "20", SO: "68", WHIP: "1.13", "K/9": "8.62" },
    { Player: "E. Vermeer", Team: "MSG", W: "5", L: "5", ERA: "3.15", G: "14", GS: "11", IP: "65.2", H: "58", R: "26", ER: "23", BB: "25", SO: "60", WHIP: "1.26", "K/9": "8.22" },
    { Player: "H. Declerck", Team: "NAM", W: "4", L: "5", ERA: "3.42", G: "13", GS: "10", IP: "60.1", H: "55", R: "28", ER: "23", BB: "21", SO: "55", WHIP: "1.26", "K/9": "8.20" },
    { Player: "I. Lemaire", Team: "BRA", W: "4", L: "6", ERA: "3.68", G: "12", GS: "12", IP: "63.2", H: "62", R: "30", ER: "26", BB: "19", SO: "52", WHIP: "1.27", "K/9": "7.35" },
    { Player: "O. Maes", Team: "DEU", W: "3", L: "6", ERA: "4.05", G: "14", GS: "9", IP: "57.2", H: "58", R: "30", ER: "26", BB: "28", SO: "48", WHIP: "1.49", "K/9": "7.49" },
  ],
  fielding: [],
  standings: [
    { Team: "Merchtem Cats", W: "22", L: "6", PCT: ".786", GB: "-" },
    { Team: "Hoboken Pioneers", W: "20", L: "8", PCT: ".714", GB: "2" },
    { Team: "Borgerhout Squirrels", W: "17", L: "11", PCT: ".607", GB: "5" },
    { Team: "Brussels Kangaroos", W: "15", L: "13", PCT: ".536", GB: "7" },
    { Team: "Mont-Saint-Guibert Phoenix", W: "13", L: "15", PCT: ".464", GB: "9" },
    { Team: "Deurne Spartans", W: "11", L: "17", PCT: ".393", GB: "11" },
    { Team: "Brasschaat Braves", W: "8", L: "20", PCT: ".286", GB: "14" },
    { Team: "Namur Angels", W: "6", L: "22", PCT: ".214", GB: "16" },
  ],
};

const TEAM_COLORS = {
  MER: { bg: "#1a1a2e", accent: "#e94560", name: "Merchtem Cats" },
  HOB: { bg: "#0f3460", accent: "#16c79a", name: "Hoboken Pioneers" },
  BOR: { bg: "#2d132c", accent: "#ee6c4d", name: "Borgerhout Squirrels" },
  BRU: { bg: "#1b2838", accent: "#66c0f4", name: "Brussels Kangaroos" },
  MSG: { bg: "#2c3333", accent: "#e6d5b8", name: "MSGuibert Phoenix" },
  DEU: { bg: "#3d0c11", accent: "#d6a2ad", name: "Deurne Spartans" },
  BRA: { bg: "#1a1c2c", accent: "#f4a261", name: "Brasschaat Braves" },
  NAM: { bg: "#0b2027", accent: "#40916c", name: "Namur Angels" },
};

const BATTING_COLS = ["Player","Team","G","AB","R","H","2B","3B","HR","RBI","BB","SO","SB","AVG","OBP","SLG","OPS"];
const PITCHING_COLS = ["Player","Team","W","L","ERA","G","GS","IP","H","R","ER","BB","SO","WHIP","K/9"];

function DiamondIcon({ size = 24, color = "#e94560" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 2L22 12L12 22L2 12L12 2Z" fill={color} opacity="0.15" />
      <path d="M12 2L22 12L12 22L2 12L12 2Z" stroke={color} strokeWidth="1.5" />
      <circle cx="12" cy="12" r="2" fill={color} opacity="0.6" />
    </svg>
  );
}

function PulseBar({ value, max, color = "#e94560", label, delay = 0 }) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
      <span style={{ fontSize: 11, color: "#8892a4", width: 36, textAlign: "right", fontFamily: "'JetBrains Mono', monospace" }}>{label}</span>
      <div style={{ flex: 1, height: 6, background: "#1a1e2e", borderRadius: 3, overflow: "hidden" }}>
        <div style={{
          height: "100%", borderRadius: 3, background: `linear-gradient(90deg, ${color}, ${color}cc)`,
          width: `${pct}%`, transition: "width 0.8s cubic-bezier(.22,1,.36,1)", transitionDelay: `${delay}ms`,
          boxShadow: `0 0 8px ${color}44`
        }} />
      </div>
      <span style={{ fontSize: 11, color: "#c8cdd5", width: 32, fontFamily: "'JetBrains Mono', monospace" }}>{value}</span>
    </div>
  );
}

function SpotlightCard({ player, stats, type, rank }) {
  const tc = TEAM_COLORS[stats.Team] || { bg: "#1a1a2e", accent: "#e94560", name: stats.Team };
  const isTop3 = rank <= 3;
  const medals = ["", "🥇", "🥈", "🥉"];

  return (
    <div style={{
      background: `linear-gradient(135deg, ${tc.bg}, #0d1117)`,
      border: `1px solid ${tc.accent}33`,
      borderRadius: 16,
      padding: "20px 18px",
      position: "relative",
      overflow: "hidden",
      transition: "transform 0.3s, box-shadow 0.3s",
      cursor: "default",
    }}
    onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = `0 12px 40px ${tc.accent}22`; }}
    onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
    >
      <div style={{
        position: "absolute", top: -30, right: -30, width: 100, height: 100,
        background: `radial-gradient(circle, ${tc.accent}15, transparent 70%)`,
      }} />
      
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
        <div>
          <div style={{ fontSize: 11, color: tc.accent, fontWeight: 600, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 4 }}>
            {isTop3 ? medals[rank] + " " : ""}#{rank}
          </div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "#edf0f5", fontFamily: "'Space Grotesk', sans-serif" }}>
            {stats.Player}
          </div>
          <div style={{ fontSize: 12, color: "#8892a4", marginTop: 2 }}>
            {tc.name} <span style={{ color: tc.accent }}>•</span> {stats.Team}
          </div>
        </div>
        <div style={{
          background: `${tc.accent}18`, border: `1px solid ${tc.accent}44`,
          borderRadius: 10, padding: "6px 12px", textAlign: "center"
        }}>
          <div style={{ fontSize: 22, fontWeight: 800, color: tc.accent, fontFamily: "'JetBrains Mono', monospace" }}>
            {type === "batting" ? stats.AVG : stats.ERA}
          </div>
          <div style={{ fontSize: 9, color: "#8892a4", letterSpacing: 1 }}>
            {type === "batting" ? "AVG" : "ERA"}
          </div>
        </div>
      </div>

      {type === "batting" ? (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2px 16px" }}>
          <PulseBar value={parseInt(stats.H)||0} max={45} color={tc.accent} label="H" delay={100} />
          <PulseBar value={parseInt(stats.HR)||0} max={8} color={tc.accent} label="HR" delay={150} />
          <PulseBar value={parseInt(stats.RBI)||0} max={35} color={tc.accent} label="RBI" delay={200} />
          <PulseBar value={parseInt(stats.SB)||0} max={15} color={tc.accent} label="SB" delay={250} />
          <PulseBar value={parseInt(stats.R)||0} max={25} color={tc.accent} label="R" delay={300} />
          <PulseBar value={parseInt(stats.BB)||0} max={20} color={tc.accent} label="BB" delay={350} />
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2px 16px" }}>
          <PulseBar value={parseInt(stats.SO)||0} max={100} color={tc.accent} label="K" delay={100} />
          <PulseBar value={parseInt(stats.W)||0} max={10} color={tc.accent} label="W" delay={150} />
          <PulseBar value={parseFloat(stats.IP)||0} max={90} color={tc.accent} label="IP" delay={200} />
          <PulseBar value={parseInt(stats.BB)||0} max={30} color="#e9456088" label="BB" delay={250} />
        </div>
      )}

      <div style={{
        display: "flex", gap: 8, marginTop: 12, paddingTop: 10,
        borderTop: `1px solid ${tc.accent}15`,
      }}>
        {type === "batting" ? (
          <>
            <MiniStat label="OBP" value={stats.OBP} color={tc.accent} />
            <MiniStat label="SLG" value={stats.SLG} color={tc.accent} />
            <MiniStat label="OPS" value={stats.OPS} color={tc.accent} />
            <MiniStat label="G" value={stats.G} color={tc.accent} />
          </>
        ) : (
          <>
            <MiniStat label="WHIP" value={stats.WHIP} color={tc.accent} />
            <MiniStat label="K/9" value={stats["K/9"]} color={tc.accent} />
            <MiniStat label="W-L" value={`${stats.W}-${stats.L}`} color={tc.accent} />
            <MiniStat label="G" value={stats.G} color={tc.accent} />
          </>
        )}
      </div>
    </div>
  );
}

function MiniStat({ label, value, color }) {
  return (
    <div style={{ flex: 1, textAlign: "center" }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: "#edf0f5", fontFamily: "'JetBrains Mono', monospace" }}>{value}</div>
      <div style={{ fontSize: 9, color: "#6b7280", letterSpacing: 1 }}>{label}</div>
    </div>
  );
}

function StatsTable({ data, columns, sortKey, sortDir, onSort, highlightCol }) {
  if (!data || data.length === 0) return <div style={{ color: "#6b7280", textAlign: "center", padding: 40 }}>Aucune donnée disponible</div>;

  return (
    <div style={{ overflowX: "auto", borderRadius: 12, border: "1px solid #1e2535" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12, fontFamily: "'JetBrains Mono', monospace" }}>
        <thead>
          <tr>
            {columns.map(col => (
              <th key={col} onClick={() => onSort(col)} style={{
                padding: "10px 8px", textAlign: col === "Player" || col === "Team" ? "left" : "right",
                background: "#0d1117", color: sortKey === col ? "#e94560" : "#6b7280",
                cursor: "pointer", borderBottom: "2px solid #1e2535", whiteSpace: "nowrap",
                fontSize: 10, letterSpacing: 1, fontWeight: 600, textTransform: "uppercase",
                position: "sticky", top: 0, zIndex: 1,
              }}>
                {col} {sortKey === col ? (sortDir === "asc" ? "↑" : "↓") : ""}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => {
            const tc = TEAM_COLORS[row.Team] || { accent: "#e94560" };
            return (
              <tr key={i} style={{ background: i % 2 === 0 ? "#0d111799" : "#12162199" }}
                onMouseEnter={e => e.currentTarget.style.background = `${tc.accent}11`}
                onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? "#0d111799" : "#12162199"}
              >
                {columns.map(col => (
                  <td key={col} style={{
                    padding: "8px 8px",
                    textAlign: col === "Player" || col === "Team" ? "left" : "right",
                    color: col === highlightCol ? tc.accent : col === "Player" ? "#edf0f5" : "#c8cdd5",
                    fontWeight: col === "Player" || col === highlightCol ? 600 : 400,
                    borderBottom: "1px solid #1e253522",
                    whiteSpace: "nowrap",
                  }}>
                    {col === "Team" ? (
                      <span style={{
                        background: `${tc.accent}20`, color: tc.accent,
                        padding: "2px 6px", borderRadius: 4, fontSize: 10, fontWeight: 700,
                      }}>{row[col]}</span>
                    ) : row[col] || "-"}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function ExportPanel({ data, filename }) {
  const exportCSV = () => {
    if (!data || data.length === 0) return;
    const headers = Object.keys(data[0]);
    const csv = [headers.join(","), ...data.map(row => headers.map(h => `"${row[h] || ""}"`).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `${filename}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `${filename}.json`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ display: "flex", gap: 8 }}>
      <button onClick={exportCSV} style={btnStyle}>⬇ CSV</button>
      <button onClick={exportJSON} style={btnStyle}>⬇ JSON</button>
    </div>
  );
}

const btnStyle = {
  background: "#1e2535", color: "#c8cdd5", border: "1px solid #2a3345",
  borderRadius: 8, padding: "6px 14px", fontSize: 12, cursor: "pointer",
  fontFamily: "'Space Grotesk', sans-serif", fontWeight: 500,
  transition: "all 0.2s",
};

export default function App() {
  const [data, setData] = useState(SAMPLE_DATA);
  const [view, setView] = useState("spotlight");
  const [statType, setStatType] = useState("batting");
  const [sortKey, setSortKey] = useState("AVG");
  const [sortDir, setSortDir] = useState("desc");
  const [teamFilter, setTeamFilter] = useState("ALL");
  const [search, setSearch] = useState("");
  const [highlightStat, setHighlightStat] = useState("AVG");
  const fileRef = useRef(null);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        setData(parsed);
      } catch (err) {
        alert("Erreur de parsing JSON. Vérifiez le format du fichier.");
      }
    };
    reader.readAsText(file);
  };

  const handleSort = useCallback((key) => {
    if (sortKey === key) {
      setSortDir(d => d === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      const numericCols = ["G","AB","R","H","2B","3B","HR","RBI","BB","SO","SB","W","L","GS","ER","AVG","OBP","SLG","OPS","ERA","IP","WHIP","K/9"];
      setSortDir(numericCols.includes(key) ? "desc" : "asc");
    }
  }, [sortKey]);

  const currentData = useMemo(() => {
    let rows = [...(data[statType] || [])];
    if (teamFilter !== "ALL") rows = rows.filter(r => r.Team === teamFilter);
    if (search) rows = rows.filter(r => r.Player?.toLowerCase().includes(search.toLowerCase()));
    
    rows.sort((a, b) => {
      let va = a[sortKey] || "", vb = b[sortKey] || "";
      const na = parseFloat(va), nb = parseFloat(vb);
      if (!isNaN(na) && !isNaN(nb)) {
        return sortDir === "asc" ? na - nb : nb - na;
      }
      return sortDir === "asc" ? va.localeCompare(vb) : vb.localeCompare(va);
    });
    return rows;
  }, [data, statType, teamFilter, search, sortKey, sortDir]);

  const teams = useMemo(() => {
    const t = new Set();
    (data.batting || []).forEach(r => t.add(r.Team));
    (data.pitching || []).forEach(r => t.add(r.Team));
    return ["ALL", ...Array.from(t).sort()];
  }, [data]);

  useEffect(() => {
    setSortKey(statType === "batting" ? "AVG" : "ERA");
    setSortDir(statType === "batting" ? "desc" : "asc");
    setHighlightStat(statType === "batting" ? "AVG" : "ERA");
  }, [statType]);

  const columns = statType === "batting" ? BATTING_COLS : PITCHING_COLS;

  return (
    <div style={{
      minHeight: "100vh", background: "#080b12", color: "#edf0f5",
      fontFamily: "'Space Grotesk', -apple-system, sans-serif",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet" />

      {/* Header */}
      <header style={{
        background: "linear-gradient(180deg, #0d1117 0%, #080b12 100%)",
        borderBottom: "1px solid #1e253544", padding: "20px 24px",
        position: "sticky", top: 0, zIndex: 10, backdropFilter: "blur(12px)",
      }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <DiamondIcon size={28} color="#e94560" />
              <div>
                <h1 style={{ margin: 0, fontSize: 20, fontWeight: 800, letterSpacing: -0.5, background: "linear-gradient(135deg, #e94560, #f4a261)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                  DIAMOND PULSE
                </h1>
                <div style={{ fontSize: 10, color: "#6b7280", letterSpacing: 2, textTransform: "uppercase" }}>
                  {data.metadata?.event} {data.metadata?.year} • KBBSF Stats
                </div>
              </div>
            </div>

            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              <input ref={fileRef} type="file" accept=".json" onChange={handleFileUpload} style={{ display: "none" }} />
              <button onClick={() => fileRef.current?.click()} style={{
                ...btnStyle, background: "#e9456020", color: "#e94560", border: "1px solid #e9456044",
              }}>
                📂 Charger JSON
              </button>
            </div>
          </div>

          {/* Nav */}
          <div style={{ display: "flex", gap: 4, marginTop: 16, flexWrap: "wrap" }}>
            {[
              { id: "spotlight", label: "⚡ Spotlight", icon: "" },
              { id: "stats", label: "📊 Stats", icon: "" },
              { id: "standings", label: "🏆 Classement", icon: "" },
              { id: "compare", label: "⚖️ Comparer", icon: "" },
            ].map(tab => (
              <button key={tab.id} onClick={() => setView(tab.id)} style={{
                ...btnStyle,
                background: view === tab.id ? "#e94560" : "#1e2535",
                color: view === tab.id ? "#fff" : "#8892a4",
                border: view === tab.id ? "1px solid #e94560" : "1px solid #2a3345",
                fontWeight: view === tab.id ? 700 : 500,
              }}>
                {tab.label}
              </button>
            ))}

            <div style={{ flex: 1 }} />

            <div style={{ display: "flex", gap: 4 }}>
              {["batting", "pitching"].map(t => (
                <button key={t} onClick={() => setStatType(t)} style={{
                  ...btnStyle,
                  background: statType === t ? "#16c79a22" : "#1e2535",
                  color: statType === t ? "#16c79a" : "#6b7280",
                  border: statType === t ? "1px solid #16c79a44" : "1px solid #2a3345",
                  textTransform: "capitalize", fontWeight: 600,
                }}>
                  {t === "batting" ? "⚾ Batting" : "🔥 Pitching"}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main style={{ maxWidth: 1200, margin: "0 auto", padding: "24px 24px 60px" }}>
        
        {/* Spotlight View */}
        {view === "spotlight" && (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
              <DiamondIcon size={20} color="#e94560" />
              <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#edf0f5" }}>
                {statType === "batting" ? "Top Frappeurs" : "Top Lanceurs"}
              </h2>
              <span style={{ fontSize: 11, color: "#6b7280" }}>— Leaders du championnat</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16 }}>
              {currentData.slice(0, 8).map((player, i) => (
                <SpotlightCard key={i} player={player.Player} stats={player} type={statType} rank={i + 1} />
              ))}
            </div>
          </div>
        )}

        {/* Stats Table View */}
        {view === "stats" && (
          <div>
            <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
              <input
                type="text" placeholder="🔍 Rechercher un joueur..."
                value={search} onChange={e => setSearch(e.target.value)}
                style={{
                  background: "#1e2535", color: "#edf0f5", border: "1px solid #2a3345",
                  borderRadius: 8, padding: "8px 14px", fontSize: 13, width: 220,
                  fontFamily: "'Space Grotesk', sans-serif", outline: "none",
                }}
              />
              <select value={teamFilter} onChange={e => setTeamFilter(e.target.value)} style={{
                background: "#1e2535", color: "#c8cdd5", border: "1px solid #2a3345",
                borderRadius: 8, padding: "8px 12px", fontSize: 12, outline: "none", cursor: "pointer",
              }}>
                {teams.map(t => <option key={t} value={t}>{t === "ALL" ? "Toutes les équipes" : (TEAM_COLORS[t]?.name || t)}</option>)}
              </select>
              <select value={highlightStat} onChange={e => setHighlightStat(e.target.value)} style={{
                background: "#1e2535", color: "#e94560", border: "1px solid #e9456044",
                borderRadius: 8, padding: "8px 12px", fontSize: 12, outline: "none", cursor: "pointer",
              }}>
                {columns.filter(c => c !== "Player" && c !== "Team").map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
              <div style={{ flex: 1 }} />
              <ExportPanel data={currentData} filename={`diamond_pulse_${statType}_${data.metadata?.year}`} />
            </div>

            <div style={{ fontSize: 11, color: "#6b7280", marginBottom: 8 }}>
              {currentData.length} joueur{currentData.length > 1 ? "s" : ""} • Cliquez sur un en-tête pour trier
            </div>

            <StatsTable data={currentData} columns={columns} sortKey={sortKey} sortDir={sortDir} onSort={handleSort} highlightCol={highlightStat} />
          </div>
        )}

        {/* Standings View */}
        {view === "standings" && (
          <div>
            <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
              <span>🏆</span> Classement {data.metadata?.event} {data.metadata?.year}
            </h2>
            {data.standings && data.standings.length > 0 ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {data.standings.map((team, i) => {
                  const code = Object.keys(TEAM_COLORS).find(k => TEAM_COLORS[k].name?.toLowerCase().includes(team.Team?.toLowerCase().split(" ")[0]));
                  const tc = TEAM_COLORS[code] || { bg: "#1a1a2e", accent: "#e94560" };
                  const w = parseInt(team.W) || 0;
                  const l = parseInt(team.L) || 0;
                  const pct = w + l > 0 ? w / (w + l) : 0;
                  return (
                    <div key={i} style={{
                      display: "flex", alignItems: "center", gap: 12,
                      background: `linear-gradient(90deg, ${tc.bg}aa, #0d111788)`,
                      border: `1px solid ${tc.accent}22`,
                      borderRadius: 12, padding: "12px 16px",
                    }}>
                      <div style={{
                        width: 32, height: 32, borderRadius: "50%",
                        background: i < 3 ? tc.accent : "#2a3345",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 14, fontWeight: 800, color: i < 3 ? "#fff" : "#6b7280",
                      }}>{i + 1}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: 14 }}>{team.Team}</div>
                      </div>
                      <div style={{ textAlign: "center", width: 60 }}>
                        <div style={{ fontSize: 16, fontWeight: 800, color: tc.accent, fontFamily: "'JetBrains Mono', monospace" }}>
                          {team.W}-{team.L}
                        </div>
                        <div style={{ fontSize: 9, color: "#6b7280" }}>W-L</div>
                      </div>
                      <div style={{ width: 120 }}>
                        <div style={{ height: 6, background: "#1a1e2e", borderRadius: 3, overflow: "hidden" }}>
                          <div style={{
                            height: "100%", borderRadius: 3, width: `${pct * 100}%`,
                            background: `linear-gradient(90deg, ${tc.accent}, ${tc.accent}88)`,
                            transition: "width 1s ease",
                          }} />
                        </div>
                        <div style={{ fontSize: 10, color: "#8892a4", textAlign: "center", marginTop: 2, fontFamily: "'JetBrains Mono', monospace" }}>
                          {team.PCT || (pct).toFixed(3)}
                        </div>
                      </div>
                      <div style={{ width: 40, textAlign: "center", fontSize: 12, color: "#6b7280", fontFamily: "'JetBrains Mono', monospace" }}>
                        {team.GB === "-" ? "—" : `+${team.GB}`}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div style={{ color: "#6b7280", textAlign: "center", padding: 40 }}>Aucune donnée de classement</div>
            )}
          </div>
        )}

        {/* Compare View */}
        {view === "compare" && <CompareView data={data} statType={statType} />}

        {/* Info banner */}
        <div style={{
          marginTop: 32, padding: "16px 20px", background: "#1e253522",
          border: "1px solid #2a334544", borderRadius: 12, fontSize: 12, color: "#6b7280",
          lineHeight: 1.6,
        }}>
          <strong style={{ color: "#e94560" }}>💡 Comment utiliser :</strong>
          <br />
          1. Lance le script <code style={{ color: "#16c79a", background: "#16c79a15", padding: "1px 6px", borderRadius: 4 }}>kbbsf_stats_scraper.py</code> sur ton PC pour récupérer les stats depuis baseballsoftball.be
          <br />
          2. Clique sur <strong style={{ color: "#e94560" }}>📂 Charger JSON</strong> pour importer le fichier généré
          <br />
          3. Explore les spotlights, trie les stats, exporte en CSV. Les données de démo sont chargées par défaut.
          <br />
          <span style={{ color: "#f4a261" }}>Source :</span> {data.metadata?.source || "baseballsoftball.be"} • Scraped: {data.metadata?.scraped_at ? new Date(data.metadata.scraped_at).toLocaleDateString("fr-BE") : "demo"}
        </div>
      </main>
    </div>
  );
}

function CompareView({ data, statType }) {
  const [p1, setP1] = useState("");
  const [p2, setP2] = useState("");
  
  const players = data[statType] || [];
  const player1 = players.find(p => p.Player === p1);
  const player2 = players.find(p => p.Player === p2);

  const compareKeys = statType === "batting"
    ? ["G","AB","R","H","2B","3B","HR","RBI","BB","SO","SB","AVG","OBP","SLG","OPS"]
    : ["W","L","ERA","G","GS","IP","H","R","ER","BB","SO","WHIP","K/9"];

  const higherIsBetter = { G:1,AB:0,R:1,H:1,"2B":1,"3B":1,HR:1,RBI:1,BB:1,SO:0,SB:1,AVG:1,OBP:1,SLG:1,OPS:1,W:1,L:0,ERA:0,GS:0,IP:1,ER:0,WHIP:0,"K/9":1 };

  return (
    <div>
      <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>⚖️ Comparer deux joueurs</h2>
      <div style={{ display: "flex", gap: 16, marginBottom: 20, flexWrap: "wrap" }}>
        <select value={p1} onChange={e => setP1(e.target.value)} style={{
          background: "#1e2535", color: "#edf0f5", border: "1px solid #e9456044",
          borderRadius: 8, padding: "10px 14px", fontSize: 13, flex: 1, minWidth: 180, outline: "none",
        }}>
          <option value="">Joueur 1...</option>
          {players.map(p => <option key={p.Player} value={p.Player}>{p.Player} ({p.Team})</option>)}
        </select>
        <div style={{ display: "flex", alignItems: "center", color: "#6b7280", fontWeight: 700, fontSize: 14 }}>VS</div>
        <select value={p2} onChange={e => setP2(e.target.value)} style={{
          background: "#1e2535", color: "#edf0f5", border: "1px solid #16c79a44",
          borderRadius: 8, padding: "10px 14px", fontSize: 13, flex: 1, minWidth: 180, outline: "none",
        }}>
          <option value="">Joueur 2...</option>
          {players.map(p => <option key={p.Player} value={p.Player}>{p.Player} ({p.Team})</option>)}
        </select>
      </div>

      {player1 && player2 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {compareKeys.map(key => {
            const v1 = parseFloat(player1[key]) || 0;
            const v2 = parseFloat(player2[key]) || 0;
            const hib = higherIsBetter[key] ?? 1;
            const winner = hib ? (v1 > v2 ? 1 : v2 > v1 ? 2 : 0) : (v1 < v2 ? 1 : v2 < v1 ? 2 : 0);

            return (
              <div key={key} style={{
                display: "flex", alignItems: "center", gap: 8, padding: "6px 12px",
                background: "#0d111788", borderRadius: 8,
              }}>
                <span style={{
                  width: 60, textAlign: "right", fontSize: 14, fontWeight: 700,
                  color: winner === 1 ? "#e94560" : "#6b7280",
                  fontFamily: "'JetBrains Mono', monospace",
                }}>{player1[key]}</span>
                <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 4 }}>
                  <div style={{ flex: 1, height: 4, background: "#1a1e2e", borderRadius: 2, overflow: "hidden", direction: "rtl" }}>
                    <div style={{
                      height: "100%", borderRadius: 2,
                      width: v1 + v2 > 0 ? `${(v1 / (v1 + v2)) * 100}%` : "50%",
                      background: winner === 1 ? "#e94560" : "#e9456066",
                    }} />
                  </div>
                  <span style={{ fontSize: 10, color: "#8892a4", width: 36, textAlign: "center", fontWeight: 600 }}>{key}</span>
                  <div style={{ flex: 1, height: 4, background: "#1a1e2e", borderRadius: 2, overflow: "hidden" }}>
                    <div style={{
                      height: "100%", borderRadius: 2,
                      width: v1 + v2 > 0 ? `${(v2 / (v1 + v2)) * 100}%` : "50%",
                      background: winner === 2 ? "#16c79a" : "#16c79a66",
                    }} />
                  </div>
                </div>
                <span style={{
                  width: 60, textAlign: "left", fontSize: 14, fontWeight: 700,
                  color: winner === 2 ? "#16c79a" : "#6b7280",
                  fontFamily: "'JetBrains Mono', monospace",
                }}>{player2[key]}</span>
              </div>
            );
          })}
          <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 12px", fontSize: 11, color: "#6b7280" }}>
            <span style={{ color: "#e94560" }}>{player1.Player} ({player1.Team})</span>
            <span style={{ color: "#16c79a" }}>{player2.Player} ({player2.Team})</span>
          </div>
        </div>
      )}

      {(!player1 || !player2) && (
        <div style={{ textAlign: "center", padding: 40, color: "#6b7280", fontSize: 14 }}>
          Sélectionne deux joueurs pour les comparer
        </div>
      )}
    </div>
  );
}
