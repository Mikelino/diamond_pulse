#!/usr/bin/env python3
"""
KBBSF Stats Scraper - Diamond Pulse Edition
=============================================
Scrape player stats from baseballsoftball.be (MyWBSC platform)
Exports batting, pitching, and fielding stats to JSON and CSV.

Requirements:
    pip install playwright pandas
    playwright install chromium

Usage:
    python kbbsf_stats_scraper.py                    # Scrape 2025 Baseball D1
    python kbbsf_stats_scraper.py --year 2026        # Scrape 2026 Baseball D1
    python kbbsf_stats_scraper.py --event softball-ladies-d1  # Softball
    python kbbsf_stats_scraper.py --all-years         # Scrape 2022-2026
"""

import asyncio
import argparse
import json
import csv
import os
from datetime import datetime

try:
    from playwright.async_api import async_playwright
except ImportError:
    print("Install playwright: pip install playwright && playwright install chromium")
    exit(1)

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False
    print("Note: Install pandas for Excel export: pip install pandas openpyxl")

BASE_URL = "https://www.baseballsoftball.be/en/events"

# Known events structure
EVENTS = {
    "baseball-d1": "Baseball D1",
    "baseball-d2": "Baseball D2",
    "softball-ladies-d1": "Softball Ladies D1",
    "softball-men-d1": "Softball Men D1",
}

STAT_CATEGORIES = ["batting", "pitching", "fielding"]


async def scrape_stats_page(page, url, category, timeout=15000):
    """Scrape a single stats page and return player data."""
    print(f"  Scraping {category}...")
    
    try:
        await page.goto(url, wait_until="networkidle", timeout=30000)
    except Exception:
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(5000)
        except Exception as e:
            print(f"    Failed to load page: {e}")
            return []

    # Wait for the stats table to appear
    try:
        await page.wait_for_selector("table", timeout=timeout)
    except Exception:
        print(f"    No table found for {category}")
        # Try clicking the category tab
        try:
            tab = await page.query_selector(f'text="{category.capitalize()}"')
            if tab:
                await tab.click()
                await page.wait_for_timeout(3000)
                await page.wait_for_selector("table", timeout=timeout)
        except Exception:
            return []

    # Extract table data
    data = await page.evaluate('''() => {
        const tables = document.querySelectorAll('table');
        const results = [];
        
        for (const table of tables) {
            const headers = [];
            const headerRow = table.querySelector('thead tr');
            if (headerRow) {
                for (const th of headerRow.querySelectorAll('th')) {
                    headers.push(th.textContent.trim());
                }
            }
            
            if (headers.length < 3) continue;  // Skip non-stat tables
            
            const rows = table.querySelectorAll('tbody tr');
            for (const row of rows) {
                const cells = row.querySelectorAll('td');
                const rowData = {};
                cells.forEach((cell, i) => {
                    if (i < headers.length) {
                        rowData[headers[i]] = cell.textContent.trim();
                    }
                });
                if (Object.keys(rowData).length > 0) {
                    results.push(rowData);
                }
            }
        }
        return results;
    }''')

    print(f"    Found {len(data)} player records")
    return data


async def scrape_team_rosters(page, event_url):
    """Scrape team rosters."""
    url = f"{event_url}/teams"
    print(f"  Scraping rosters from {url}...")
    
    try:
        await page.goto(url, wait_until="networkidle", timeout=30000)
    except Exception:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        await page.wait_for_timeout(5000)

    # Get team links
    teams = await page.evaluate('''() => {
        const links = document.querySelectorAll('a[href*="/teams/"]');
        return Array.from(links).map(a => ({
            name: a.textContent.trim(),
            url: a.href
        })).filter(t => t.name && t.name.length > 1);
    }''')

    print(f"    Found {len(teams)} teams")
    
    rosters = {}
    for team in teams:
        if not team['name'] or team['name'] in rosters:
            continue
        try:
            await page.goto(team['url'], wait_until="networkidle", timeout=20000)
            players = await page.evaluate('''() => {
                const rows = document.querySelectorAll('table tbody tr');
                return Array.from(rows).map(row => {
                    const cells = row.querySelectorAll('td');
                    return {
                        number: cells[0]?.textContent?.trim() || '',
                        name: cells[1]?.textContent?.trim() || '',
                        position: cells[2]?.textContent?.trim() || '',
                        bats_throws: cells[3]?.textContent?.trim() || '',
                    };
                }).filter(p => p.name);
            }''')
            rosters[team['name']] = players
            print(f"      {team['name']}: {len(players)} players")
        except Exception as e:
            print(f"      Error loading {team['name']}: {e}")

    return rosters


async def scrape_standings(page, event_url):
    """Scrape standings."""
    url = f"{event_url}/standings"
    print(f"  Scraping standings from {url}...")

    try:
        await page.goto(url, wait_until="networkidle", timeout=30000)
    except Exception:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        await page.wait_for_timeout(5000)

    standings = await page.evaluate('''() => {
        const tables = document.querySelectorAll('table');
        const results = [];
        for (const table of tables) {
            const headers = [];
            const headerRow = table.querySelector('thead tr');
            if (headerRow) {
                for (const th of headerRow.querySelectorAll('th')) {
                    headers.push(th.textContent.trim());
                }
            }
            const rows = table.querySelectorAll('tbody tr');
            for (const row of rows) {
                const cells = row.querySelectorAll('td');
                const rowData = {};
                cells.forEach((cell, i) => {
                    if (i < headers.length) {
                        rowData[headers[i]] = cell.textContent.trim();
                    }
                });
                if (Object.keys(rowData).length > 0) {
                    results.push(rowData);
                }
            }
        }
        return results;
    }''')

    print(f"    Found {len(standings)} standings entries")
    return standings


async def scrape_event(year, event_slug, output_dir):
    """Scrape all stats for a given event."""
    event_name = EVENTS.get(event_slug, event_slug)
    event_url = f"{BASE_URL}/{year}-{event_slug}"
    
    if year >= 2026:
        # 2026 uses different URL pattern
        event_url = f"{BASE_URL}/{year}-{event_slug}-{year}"
    
    print(f"\n{'='*60}")
    print(f"Scraping: {event_name} {year}")
    print(f"URL: {event_url}")
    print(f"{'='*60}")

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        )
        page = await context.new_page()

        all_stats = {
            "metadata": {
                "event": event_name,
                "year": year,
                "scraped_at": datetime.now().isoformat(),
                "source": event_url,
            },
            "batting": [],
            "pitching": [],
            "fielding": [],
            "standings": [],
            "rosters": {},
        }

        # Scrape each stat category
        for category in STAT_CATEGORIES:
            stats_url = f"{event_url}/stats/general/all/{category}"
            data = await scrape_stats_page(page, stats_url, category)
            all_stats[category] = data

            # Also try team-by-team stats
            if not data:
                # Try the main stats page and click tabs
                stats_url = f"{event_url}/stats"
                data = await scrape_stats_page(page, stats_url, category)
                all_stats[category] = data

        # Scrape standings
        all_stats["standings"] = await scrape_standings(page, event_url)

        # Scrape rosters
        all_stats["rosters"] = await scrape_team_rosters(page, event_url)

        await browser.close()

    # Save outputs
    os.makedirs(output_dir, exist_ok=True)
    
    # JSON export (complete data)
    json_path = os.path.join(output_dir, f"{event_slug}_{year}_stats.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(all_stats, f, indent=2, ensure_ascii=False)
    print(f"\nJSON saved: {json_path}")

    # CSV exports per category
    for category in STAT_CATEGORIES:
        if all_stats[category]:
            csv_path = os.path.join(output_dir, f"{event_slug}_{year}_{category}.csv")
            with open(csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=all_stats[category][0].keys())
                writer.writeheader()
                writer.writerows(all_stats[category])
            print(f"CSV saved: {csv_path}")

    # Excel export if pandas available
    if HAS_PANDAS and any(all_stats[c] for c in STAT_CATEGORIES):
        xlsx_path = os.path.join(output_dir, f"{event_slug}_{year}_stats.xlsx")
        with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
            for category in STAT_CATEGORIES:
                if all_stats[category]:
                    df = pd.DataFrame(all_stats[category])
                    df.to_excel(writer, sheet_name=category.capitalize(), index=False)
            if all_stats["standings"]:
                df = pd.DataFrame(all_stats["standings"])
                df.to_excel(writer, sheet_name="Standings", index=False)
        print(f"Excel saved: {xlsx_path}")

    return all_stats


async def main():
    parser = argparse.ArgumentParser(description="KBBSF Stats Scraper for Diamond Pulse")
    parser.add_argument("--year", type=int, default=2025, help="Season year (default: 2025)")
    parser.add_argument("--event", default="baseball-d1", 
                        choices=list(EVENTS.keys()),
                        help="Event slug")
    parser.add_argument("--all-years", action="store_true",
                        help="Scrape all years 2022-2026")
    parser.add_argument("--all-events", action="store_true",
                        help="Scrape all events for the given year")
    parser.add_argument("--output", default="diamond_pulse_data",
                        help="Output directory")
    
    args = parser.parse_args()

    if args.all_years:
        for year in range(2022, 2027):
            if args.all_events:
                for event in EVENTS:
                    try:
                        await scrape_event(year, event, args.output)
                    except Exception as e:
                        print(f"Error scraping {event} {year}: {e}")
            else:
                try:
                    await scrape_event(year, args.event, args.output)
                except Exception as e:
                    print(f"Error scraping {args.event} {year}: {e}")
    elif args.all_events:
        for event in EVENTS:
            try:
                await scrape_event(args.year, event, args.output)
            except Exception as e:
                print(f"Error scraping {event} {args.year}: {e}")
    else:
        await scrape_event(args.year, args.event, args.output)

    print(f"\n{'='*60}")
    print(f"All data saved to: {args.output}/")
    print(f"Use the Diamond Pulse Stats Viewer to analyze the data!")
    print(f"{'='*60}")


if __name__ == "__main__":
    asyncio.run(main())
